<?php
include "connectiondb.php";
session_start();
$action = $_POST['action'];
$emailid=$_SESSION['emailid'];
$_SESSION['emailid'] = $emailid;
$action = $_POST['action'];
if($action=="Add")
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $contact=$_POST['contact'];
    $line1=$_POST['line1'];
    $line2=$_POST['line2'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
    $sql_query = "insert into laboratory(name,emailid,password,contact,addressline1,addressline2,city,state,zip)
    values('".$name."','".$email."','".$password."','".$contact."','".$line1."','".$line2."','".$city."','".$state."','".$zip."')";
    $retval1 = mysqli_query($conn, $sql_query);
    if($retval1)
    {
        header('Location: ../Laboratory.php');
    }
    else
    {
        header('Location: ../Laboratory.php');
    }
}
?>