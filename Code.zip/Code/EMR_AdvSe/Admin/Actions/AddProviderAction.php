<?php
include "connectiondb.php";
session_start();
$action = $_POST['action'];
$emailid=$_SESSION['emailid'];
$_SESSION['emailid'] = $emailid;
$action = $_POST['action'];
if($action=="Add")
{
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $dob=$_POST['dob'];
    $dob=DATE("Y-m-d",strtotime($dob));
    $email=$_POST['email'];
    $password=$_POST['password'];
    $contact=$_POST['contact'];
    $gender=$_POST['gender'];
    $line1=$_POST['line1'];
    $line2=$_POST['line2'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
    $license=$_POST['license'];
    $speciality=$_POST['speciality'];
    $sql_query = "insert into provider(firstname,lastname,dob,gender,emailid,password,contact,addressline1,addressline2,city,state,zip,license,speciality)
    values('".$fname."','".$lname."','$dob','".$gender."','".$email."','".$password."','".$contact."','".$line1."','".$line2."','".$city."','".$state."','".$zip."','".$license."','".$speciality."')";
    $retval1 = mysqli_query($conn, $sql_query);
    if($retval1)
    {
        header('Location: ../Provider.php');
    }
    else
    {
        header('Location: ../Provider.php');
    }
}
?>