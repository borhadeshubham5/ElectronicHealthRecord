<?php
include "connectiondb.php";
session_start();
$action = $_POST['action'];
$emailid=$_SESSION['emailid'];
$_SESSION['emailid'] = $emailid;
$action = $_POST['action'];
if($action=="Update")
{
    $email=$_POST['email'];
    $password=$_POST['password'];
    $sql_query = "update admin set password='".$password."' where emailid='".$email."'";
    $retval1 = mysqli_query($conn, $sql_query);
    if($retval1)
    {
        header('Location: ../Profile.php');
    }
    else
    {
        header('Location: ../Profile.php');
    }
}
?>