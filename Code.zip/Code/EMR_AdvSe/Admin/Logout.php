<?php
session_start();
session_destroy();
ini_set('session.gc_max_lifetime', 0);
ini_set('session.gc_probability', 1);
ini_set('session.gc_divisor', 1);
header('Location: Login.php');
?>