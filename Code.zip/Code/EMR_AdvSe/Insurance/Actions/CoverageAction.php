<?php
include "connectiondb.php";
session_start();
$insurerid=$_SESSION['insurerid'];
$uname=$_SESSION['uname'];
$_SESSION['insurerid'] = $insurerid;
$_SESSION['uname'] = $uname;
    $chargeid=$_POST['chargeid'];
    $inscoverage=$_POST['inscoverage'];
    $sql_query = "update accountcharges set insurancecoverage=$inscoverage, status='Complete', balance=0 where chargeid=$chargeid limit 1";
    $result = mysqli_query($conn,$sql_query);
    if($result)
    {
        header('Location: ../Home.php');
    }
    else
    {
        header('Location: ../Home.php');
    }

