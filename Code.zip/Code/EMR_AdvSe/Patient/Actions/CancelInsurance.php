<?php
include "connectiondb.php";
session_start();
$patientid=$_SESSION['patientid'];
$uname=$_SESSION['uname'];
$_SESSION['patientid'] = $patientid;
$_SESSION['uname'] = $uname;
$insuranceid=$_GET['insuranceid'];
        $sql_query = "update patientinsurance set status='Inactive' where insuranceid=$insuranceid and patientid=$patientid limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Insurance.php');
        }
        else
        {
            header('Location: ../Insurance.php');
        }



