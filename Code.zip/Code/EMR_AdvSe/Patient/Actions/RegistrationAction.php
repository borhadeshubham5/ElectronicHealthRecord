<?php
include "connectiondb.php";
session_start();
$action = $_POST['action'];
if($action=="Register")
{
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $dob=$_POST['dob'];
    $gender=$_POST['gender'];
    $email=$_POST['email'];
    $contact=$_POST['contact'];
    $password=$_POST['password'];
    $address1=$_POST['address1'];
    $address2=$_POST['address2'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
        $sql_query = "insert into patient(firstname,lastname,gender,dob,emailid,password,contact,addressline1,addressline2,city,state,zip)
        values('$fname','$lname','$gender','$dob','$email','$password','$contact','$address1','$address2','$city','$state','$zip')";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Login.php');
        }
        else
        {
            header('Location: ../Register.php');
        }
}
