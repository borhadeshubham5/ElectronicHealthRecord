<?php
include "connectiondb.php";
session_start();
$action = $_POST['action'];
$patientid=$_SESSION['patientid'];
$uname=$_SESSION['uname'];
$_SESSION['patientid'] = $patientid;
$_SESSION['uname'] = $uname;
if($action=="Book")
{
    $vdate=$_POST['vdate'];
    $dob=DATE("Y-m-d",strtotime($vdate));
    $vtime=$_POST['vtime'];
    $patientnotes=$_POST['patientnotes'];
        $sql_query = "insert into visits(patientid,providerid,vdate,vtime,patientnotes,providernotes,symptoms,diagnosis,status)
        values($patientid,11,'$vdate','$vtime','$patientnotes','Default','Default','Default','Booked')";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Appointments.php');
        }
        else
        {
            header('Location: ../Appointments.php');
        }
}
else if($action=="Save Address1")
{
    $addrline1=$_POST['addrline1'];
    $addrline2=$_POST['addrline2'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
        $sql_query = "update patientaddress set addressline1='$addrline1', addressline2='$addrline2', city='$city', state='$state', zip='$zip' where patientid=$patientid and type='Billing' limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Profile.php');
        }
        else
        {
            header('Location: ../Profile.php');
        }
}
else if($action=="Save Address2")
{
    $addrline1=$_POST['addrline1'];
    $addrline2=$_POST['addrline2'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
        $sql_query = "update patientaddress set addressline1='$addrline1', addressline2='$addrline2', city='$city', state='$state', zip='$zip' where patientid=$patientid and type='Mailing' limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Profile.php');
        }
        else
        {
            header('Location: ../Profile.php');
        }
}
