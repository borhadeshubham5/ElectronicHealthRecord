<?php
include "connectiondb.php";
session_start();
$action = $_POST['action'];
$patientid=$_SESSION['patientid'];
$uname=$_SESSION['uname'];
$_SESSION['patientid'] = $patientid;
$_SESSION['uname'] = $uname;
if($action=="Add")
{
    $edate=$_POST['edate'];
    $edate=DATE("Y-m-d",strtotime($edate));
    $InsCompany=$_POST['InsCompany'];
    echo "value of ins is: ".$InsCompany;
    $sql2="select insurerid from insurancecompany where name='$InsCompany'";
    $retval2 = mysqli_query($conn, $sql2);
    if($row2 = mysqli_fetch_array($retval2))
    {
        echo "inside if";
        $insid=$row2[0];
        $sql_query = "insert into patientinsurance(patientid,insurerid,expiry,status)
        values($patientid,$insid,'$edate','Active')";
        echo $sql_query;
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Insurance.php');
        }
        else
        {
            header('Location: ../Insurance.php');
        }
    }     
}
?>