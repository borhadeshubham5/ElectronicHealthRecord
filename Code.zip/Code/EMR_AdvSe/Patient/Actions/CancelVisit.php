<?php
include "connectiondb.php";
session_start();
$patientid=$_SESSION['patientid'];
$uname=$_SESSION['uname'];
$_SESSION['patientid'] = $patientid;
$_SESSION['uname'] = $uname;
$visitid=$_GET['visitid'];
        $sql_query = "update visits set status='Canceled' where visitid=$visitid and patientid=$patientid limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Appointments.php');
        }
        else
        {
            header('Location: ../Appointments.php');
        }



