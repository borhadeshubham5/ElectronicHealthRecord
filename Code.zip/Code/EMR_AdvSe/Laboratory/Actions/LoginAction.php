<?php
include "connectiondb.php";
$action = $_POST['action'];
if($action=="Login")
{
    $email=$_POST['email'];
    $password=$_POST['password'];
    if ($email != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from laboratory where emailid='".$email."' and password='".$password."'";
        $result = mysqli_query($conn,$sql_query);
        $row = mysqli_fetch_array($result);
        $count = $row['cntUser'];
        $count = $row[0];
        if($count > 0)
        {
            $sql = "SELECT laboratoryid, name, emailid FROM laboratory where emailid='".$email."'";
            $retval = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($retval)) 
            {
                $laboratoryid=$row[0];
                $fname=$row[1];
                $emailid=$row[2];
                $uname=$fname;
                session_start();
                $_SESSION['laboratoryid'] = $laboratoryid;
                $_SESSION['uname'] = $uname;
                header('Location: ../Home.php');
            }
        }
        else
        {
            session_start();
            $alertmessage='Invalid credentials!';
            $_SESSION['alert'] = $alertmessage;
            header('Location: ../Login.php');
        }
    }
}