<?php
include "connectiondb.php";
session_start();
$laboratoryid=$_SESSION['laboratoryid'];
$uname=$_SESSION['uname'];
$_SESSION['laboratoryid'] = $laboratoryid;
$_SESSION['uname'] = $uname;
    $testid=$_POST['testid'];
    $testreport=$_POST['testreport'];
    $tdate=date("Y-m-d");
    $sql_query = "update labtests set testreport='$testreport', tdate='$tdate', status='Complete' where testid=$testid limit 1";
    $result = mysqli_query($conn,$sql_query);
    if($result)
    {
        header('Location: ../Home.php');
    }
    else
    {
        header('Location: ../Home.php');
    }

