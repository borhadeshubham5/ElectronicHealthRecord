<?php
include "connectiondb.php";
session_start();
$pharmacyid=$_SESSION['pharmacyid'];
$uname=$_SESSION['uname'];
$_SESSION['pharmacyid'] = $pharmacyid;
$_SESSION['uname'] = $uname;
    $medid=$_GET['medid'];
    $sql_query = "update medications set status='Complete' where medicationid=$medid limit 1";
    $result = mysqli_query($conn,$sql_query);
    if($result)
    {
        header('Location: ../Home.php');
    }
    else
    {
        header('Location: ../Home.php');
    }

