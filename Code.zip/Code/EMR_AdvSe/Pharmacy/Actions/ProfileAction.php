<?php
include "connectiondb.php";
session_start();
$pharmacyid=$_SESSION['pharmacyid'];
$uname=$_SESSION['uname'];
$_SESSION['pharmacyid'] = $pharmacyid;
$_SESSION['uname'] = $uname;
$action=$_POST['action'];
if($action=="Save Personal Details")
{
    $name=$_POST['name'];
    $emailid=$_POST['emailid'];
    $password=$_POST['password'];
    $contact=$_POST['contact'];
    $addressline1=$_POST['address1'];
    $addressline2=$_POST['address2'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
        $sql_query = "update pharmacy set name='$name', contact='$contact', password='$password', addressline1='$addressline1', addressline2='$addressline2', city='$city', state='$state', zip='$zip' where pharmacyid=$pharmacyid limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                $uname=$name;
                $_SESSION['uname'] = $uname;
                header('Location: ../Profile.php');
        }
        else
        {
            header('Location: ../Profile.php');
        }
}
