<?php
include "connectiondb.php";
session_start();
$providerid=$_SESSION['providerid'];
$uname=$_SESSION['uname'];
$_SESSION['providerid'] = $providerid;
$_SESSION['uname'] = $uname;
$action=$_POST['action'];
if($action=="Save Lab")
{
    $testname=$_POST['testname'];
    $labname=$_POST['labname'];
    $visitid=$_POST['visitid'];
    $tdate=date("Y-m-d");
    $sql1="select laboratoryid from laboratory where name='$labname'";
    $result1 = mysqli_query($conn,$sql1);
    if($row2 = mysqli_fetch_array($result1))
    {
        $labid=$row2[0];
        $sql_query = "insert into labtests(labid, visitid,testname,testreport,tdate,status) values($labid,$visitid,'$testname','Pending','$tdate','Pending')";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
            header('Location: ../VisitByID.php?visitid='.$visitid);
        }
        else
        {
            header('Location: ../VisitByID.php?visitid='.$visitid);
        }
    }
}
