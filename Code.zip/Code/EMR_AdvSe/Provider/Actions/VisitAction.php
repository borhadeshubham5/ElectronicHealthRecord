<?php
include "connectiondb.php";
session_start();
$providerid=$_SESSION['providerid'];
$uname=$_SESSION['uname'];
$_SESSION['providerid'] = $providerid;
$_SESSION['uname'] = $uname;
$action=$_POST['action'];
if($action=="Save Details")
{
    $symptoms=$_POST['symptoms'];
    $diagnosis=$_POST['diagnosis'];
    $providernotes=$_POST['providernotes'];
    $status='Complete';
    $visitid=$_POST['visitid'];
        $sql_query = "update visits set providerid=$providerid, symptoms='$symptoms', diagnosis='$diagnosis', providernotes='$providernotes', status='$status' where visitid=$visitid limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
            header('Location: ../VisitByID.php?visitid='.$visitid);
        }
        else
        {
            header('Location: ../VisitByID.php?visitid='.$visitid);
        }
}
