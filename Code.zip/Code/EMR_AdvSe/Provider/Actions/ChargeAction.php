<?php
include "connectiondb.php";
session_start();
$providerid=$_SESSION['providerid'];
$uname=$_SESSION['uname'];
$_SESSION['providerid'] = $providerid;
$_SESSION['uname'] = $uname;
$action=$_POST['action'];
if($action=="Save Charges")
{
    $charges=$_POST['charges'];
    $patientpay=$_POST['patientpay'];
    if($charges==$patientpay)
    {
        $status='Complete';
        $balance=0;
    }
    else
    {
        $status='Pending';
        $balance=$charges-$patientpay;
    }
    $visitid=$_POST['visitid'];
        $sql_query = "insert into accountcharges(visitid,charges,patientpayment,insurancecoverage,status,balance)
        values($visitid,$charges,$patientpay,0,'$status',$balance)";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
            header('Location: ../VisitByID.php?visitid='.$visitid);
        }
        else
        {
            header('Location: ../VisitByID.php?visitid='.$visitid);
        }
}
