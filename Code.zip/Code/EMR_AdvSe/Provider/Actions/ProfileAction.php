<?php
include "connectiondb.php";
session_start();
$providerid=$_SESSION['providerid'];
$uname=$_SESSION['uname'];
$_SESSION['providerid'] = $providerid;
$_SESSION['uname'] = $uname;
$action=$_POST['action'];
if($action=="Save Personal Details")
{
    $fname=$_POST['ufname'];
    $lname=$_POST['ulname'];
    $dob=$_POST['udob'];
    $contact=$_POST['ucontact'];
    $password=$_POST['upassword'];
        $sql_query = "update provider set firstname='$fname', lastname='$lname', dob='$dob', contact='$contact', password='$password' where providerid=$providerid limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                $uname=$fname." ".$lname;
                $_SESSION['uname'] = $uname;
                header('Location: ../Profile.php');
        }
        else
        {
            header('Location: ../Profile.php');
        }
}
else if($action=="Save Address")
{
    $addrline1=$_POST['addrline1'];
    $addrline2=$_POST['addrline2'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];
        $sql_query = "update provider set addressline1='$addrline1', addressline2='$addrline2', city='$city', state='$state', zip='$zip' where providerid=$providerid limit 1";
        $result = mysqli_query($conn,$sql_query);
        if($result)
        {
                header('Location: ../Profile.php');
        }
        else
        {
            header('Location: ../Profile.php');
        }
}
