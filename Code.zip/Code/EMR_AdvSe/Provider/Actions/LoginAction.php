<?php
include "connectiondb.php";
$action = $_POST['action'];
if($action=="Login")
{
    $email=$_POST['email'];
    $password=$_POST['password'];
    if ($email != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from provider where emailid='".$email."' and password='".$password."'";
        $result = mysqli_query($conn,$sql_query);
        $row = mysqli_fetch_array($result);
        $count = $row['cntUser'];
        $count = $row[0];
        if($count > 0)
        {
            $sql = "SELECT providerid, firstname, lastname, emailid FROM provider where emailid='".$email."'";
            $retval = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($retval)) 
            {
                $providerid=$row[0];
                $fname=$row[1];
                $lname=$row[2];
                $emailid=$row[3];
                $uname=$fname.$lname;
                session_start();
                $_SESSION['providerid'] = $providerid;
                $_SESSION['uname'] = $uname;
                header('Location: ../Home.php');
            }
        }
        else
        {
            session_start();
            $alertmessage='Invalid credentials!';
            $_SESSION['alert'] = $alertmessage;
            header('Location: ../Login.php');
        }
    }
}